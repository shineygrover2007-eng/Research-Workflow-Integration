# COVID-19 Research Workflow

This repository integrates data, analysis, report, and references for a mini research project on COVID-19.

## Structure
- **data/**: Contains datasets (CSV)
- **notebooks/**: Jupyter notebooks for analysis
- **report/**: Final report in Markdown
- **references/**: Bibliographic references (.bib)
